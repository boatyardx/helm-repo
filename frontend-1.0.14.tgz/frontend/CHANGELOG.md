# CHANGELOG

# 1.0.14
* optimised the oauth config to accomodate dynamic changes for a wider set of deployments.

# 1.0.13
* added customizable lifecycle hooks. To easily configure preStop and postStart hooks

# 1.0.12
* added helm hooks - capacity to run custom scripts at different helm deployment stages (pre-install, post-upgrade, post-rollback and many more)

# 1.0.11
* added nodeSelector:[] to schedule pods on nodes with specific labels (e.g., ssrnodepool: true, environment: production)
* added tolerations:[] to tolerate node taints (allow pod deployment on dedicated VMs)

# 1.0.10
* Changed the deployment strategy to fix a conflict if the "recreate" strategy is used
* Added "terminationGracePeriodSeconds" to be able to control the killing time of the old pods
* Changed "minReadySeconds" to be customisable

# 1.0.9
* Added startupProbe to automate the spinup process entirely and make the service serve traffic asap
* Changed the pod spread topology to filter after the release name value

# 1.0.8

* Added topologySpreadConstraints to allow replicas to be deployed evenly accross all nodes
* Added hpa on frontend template
* Added apm integration (annotation label required by apm agent)

# 1.0.7

* made the liveness and readiness path and port editable

# 1.0.6

* Increased the oauth2 proxy timeout to 600s

# 1.0.5

* Added oauth2-proxy support. Used Image: quay.io/oauth2-proxy/oauth2-proxy:v7.5.1

# 1.0.4

* Fix the default value of autoscaling

# 1.0.3

* Made the deployment strategy parameters configurable

# 1.0.2

* Made the path of the ingress cofigurable
* Made the resource limists and requests configurable

## 1.0.1 Kubernetes 1.23

* ingress apiVersion extensions/v1beta1 was changed to extensions/v1

## 1.0.0 Kubernetes 1.22.

* Ingress apiVersion networking.k8s.io/v1
* Ingress spec.path.serviceName -> spec.path.service.name
* Ingress spec.path.servicePort -> spec.path.service.port.number

## 0.3.2

* ingress apiVersion extensions/v1beta1 not supported anymore. 

## 0.3.1

* Ingress annotation must specify "ingress.class: nginx" for external-dns
* Not compatible with kubernetes 1.22.X
