# Frontend


## authProxy — full options (requires v1.0.14+)

```yaml
authProxy:
  enabled: true
  image: "quay.io/oauth2-proxy/oauth2-proxy:v7.5.1"  # override image version
  oidcIssuerUrl: "https://iam.env.domain.com/auth/realms/realm"
  oidcClientId: "client-id"

  # Required when sitting behind a path-based reverse proxy (e.g. Fastly + Next.js)
  proxyPrefix: "/_next/auth"
  redirectUrl: "https://your-domain.com/_next/auth/callback"
  reverseProxy: true                        # adds --reverse-proxy=true
  whitelistDomains:
    - "your-domain.com"
  skipAuthRoutes:                           # regex routes that bypass auth
    - "^/_next/static/.*"
    - "^/_next/image.*"
    - "^/favicon.*"
    - "^/next-api/.*"
  extraArgs: []                             # any additional oauth2-proxy CLI flags
  redis:
    enabled: true   # default; set false to use cookie store instead
    tls: true       # true = rediss://, false = redis://
```

> Secrets `oauth2-proxy-secrets` (keys: `OAUTH_UPTIME_CLIENT_SECRET`, `OAUTH_UPTIME_COOKIE_SECRET`) and `redis-credentials` (keys: `host`, `port`, `primaryAccessKey`) must exist in the namespace when their respective features are enabled.
