# Change Log

The release numbering uses [semantic versioning](http://semver.org).

## 1.1.2
* Upgrade upstream Jenkins Helm Chart to https://github.com/jenkinsci/helm-charts

## 1.1.1

* Added support for a new custom credential, support for secret texts

## 1.1.0

* Update Jenkins Kubernetes Agent setup to use Docker in Docker sidecar;
  **this might cause breaking changes, depending on your CI pipeline configuration.**

## 1.0.3

* Fix error `Required value: pathType must be specified` on Ingress resource when deploying on Kubernetes >= 1.19.

## 1.0.2

* Fix init container error when there's a newer version of a dependency plugin than the version specified in the provided list (see https://github.com/jenkinsci/helm-charts/issues/186)

## 1.0.1

* Fix template to generate startup probe only for Kubernetes >= 1.18
* Fix gitlab-branch-source config with required secretToken parameter. 

## 1.0.0

* Upgrade upstream Jenkins Helm Chart to https://github.com/jenkinsci/helm-charts
  * update Jenkins image and appVersion to jenkins lts release version 2.263.4
  * chart uses StatefulSet instead of Deployment
  * XML configuration was removed in favor of JCasC
  * chart migrated to Helm 3.0.0 (apiVersion v2)
  * values have been renamed and re-ordered to make it easier to use
  * componentName for the controller is now jenkins-controller 
  * container names are now
    * `init` for the init container which downloads Jenkins plugins
    * `jenkins` for the Jenkins controller
    * `config-reload` for the sidecar container which automatically reloads JCasC

## 0.15.0

* Add pod affinity/anti-affinity configuration to distribute the jenkins agents among the available/selected nodes.

## 0.14.1

* Fix template error when Jenkins credentials (user/passwords or files) are not provided

## 0.14.0

* Set custom Content Security Policy

## 0.13.0

* Add generic-webhook-trigger plugin 1.72

## 0.12.0

* Add ssh-agent plugin 1.20
* Update dependency chart repo URL

## 0.11.0

* Added support for custom credentials, support for username/password and files

## 0.10.4

* Lock all plugins versions

## 0.10.3

* Added the pipeline: declarative v 1.7.1 to the chart to auto install

## 0.10.2

* Fix chart syntax

## 0.10.1

* Fix chart syntax error

## 0.10.0

* Add ability to configure the idle time after which the agents are destroyed
* Add ability to scan multiple GitLab groups - each group is a separate Seed Job/Organization Scan folder

## 0.9.1

* Fixed an error where it was using $container.name as a literal instead of using the variable value

## 0.9.0

* Add /dev/shm volume if needed by a container with the shm flag

## 0.8.0

* Add support to configure the SonarQube Scanner webhook authentication settings.

## 0.7.0

* Add support for SonarQube Scanner.

## 0.6.1

* Revert GitLab plugin to 1.5.13

## 0.6.0

* Update Jenkins to 2.230-alpine
* Add AnsiColor plugin 0.6.3
* Add Cucumber Reports plugin 5.0.2
* Add HTML Publisher plugin 1.22
* Update Kubernetes plugin to 1.25.2
* Update Pipeline plugin to 2.38
* Update Jenkins Configuration as Code plugin to 1.38
* Update GitLab Branch Source plugin to 1.4.5

## 0.5.0

* Add config to set the maximum number of concurrently running agent pods that are permitted in the Kubernetes Cloud.

## 0.4.0

* Update Jenkins to 2.226-alpine
* Add Office365Connector plugin 1.8
* Add OWASP Markup Formatter Plugin and JCasC configuration 4.12.4
* Update Kubernetes plugin to 1.25.1
* Update Job DSL plugin to 1.77
* Update GitLab Branch Source plugin to 1.4.4
* Update Jenkins Configuration as Code plugin to 1.36
* Update Git plugin to 4.2.2
* Update Credential Binding plugin to 1.21
* Update Pipeline plugin to 2.37

## 0.3.0

Added service agent to the kubernetes_cloud.yaml.tpl so we can pass a service account to use by the jenkins agents

## 0.2.0

Added annotations to the agent pod template which is used by aws to pass credentials from an IAM role to the jenkins pod

## 0.1.0

Initial release
