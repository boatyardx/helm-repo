{{- define "jenkins_agent_pod_template.yaml" }}
apiVersion: v1
kind: Pod
metadata:
  labels:
    shipyardtech.com/factoryService: jenkins-agent
{{- if .Values.jenkins.controller.kubernetes.agentPodTemplate.labels }}
{{ toYaml .Values.jenkins.controller.kubernetes.agentPodTemplate.labels | indent 4 }}
{{- end }}
{{- if .Values.jenkins.controller.kubernetes.agentPodTemplate.annotations }}
  annotations:
{{ toYaml .Values.jenkins.controller.kubernetes.agentPodTemplate.annotations | indent 4 }}
{{- end }}
spec:
# ## Affinity Rules
# We want to schedule jenkins agents evenly to avoid situations where all agents are schedules on the same node and compete for CPU time.
# The pod anti-affinity rule below means: try not to schedule the jenkins agent pod on a node N with label kubernetes.io/hostname = V
# if there is already a node with label kubernetes.io/hostname = V running a pod with label shipyardtech.com/factoryService = jenkins-agent.
# Pod Topology Spread Constraints are a better solution but it's supported only from Kubernetes 1.19
  affinity:
    nodeAffinity:
      preferredDuringSchedulingIgnoredDuringExecution:
        - weight: 100
          preference:
            matchExpressions:
              - key: shipyardtech.com/factoryService
                operator: In
                values:
                  - CICD
    podAntiAffinity:
      preferredDuringSchedulingIgnoredDuringExecution:
        - weight: 100
          podAffinityTerm:
            labelSelector:
              matchExpressions:
                - key: shipyardtech.com/factoryService
                  operator: In
                  values:
                    - jenkins-agent
            topologyKey: kubernetes.io/hostname
# ## Containers
  containers:
    # the Docker in Docker sidecar container
    # **must** run in privileged mode
    - name: dind
      image: docker:20.10.7-dind@sha256:a5b401c7baadaa320d68336f47eaddc57cd479dbcb41ed65ab5ef89d446a3e36
      securityContext:
        privileged: true
      env:
        - name: DOCKER_TLS_CERTDIR
          value: /certs
      volumeMounts:
        - name: docker-graph-storage
          mountPath: /var/lib/docker
        - name: docker-certs
          mountPath: /certs
{{- range $index, $container := .Values.jenkins.controller.kubernetes.agentPodTemplate.containers }}
    - name: {{ $container.name }}
      image: {{ $container.image }}
      command:
{{ toYaml $container.command | indent 8 }}
      tty: {{ $container.tty }}
      env:
        - name: IS_CI
          value: "YES"
        # each container can call the docker daemon on the shared port
        - name: DOCKER_HOST
          value: "tcp://localhost:2376"
        # force the docker clients to use TLS
        - name: DOCKER_TLS_VERIFY
          value: "1"
        # path where the docker daemon TLS cert is stored
        - name: DOCKER_CERT_PATH
          value: /certs/client
      volumeMounts:
        # The dir containing the docker daemon TLS certs is mounted in ro mode
        - name: docker-certs
          mountPath: /certs
          readOnly: true
{{if $container.shm}}
        - name: {{ $container.name }}
          mountPath: /dev/shm
{{- end }}
{{- end }}
  volumes:
    # Store the docker graph dir on the host
    # This is removed when the container is deleted
    - name: docker-graph-storage
      emptyDir: {}
    # Since Docker 20.x, TLS is enabled by default
    # The DinD container will generate TLS certs at start up and store them under DOCKER_TLS_CERTDIR
    # This folder is shared (in ro mode) among all other containers
    - name: docker-certs
      emptyDir: {}
{{- range $index, $container := .Values.jenkins.controller.kubernetes.agentPodTemplate.containers }}
{{if $container.shm}}
    - name: {{ $container.name }}
      emptyDir:
        medium: Memory
{{- end }}
{{- end }}
{{- end }}
