# CHANGELOG

# 0.3.1
* oauth2-proxy session store is selectable via `authProxy.sessionStore`: `redis` (default) or `cookie`
* `cookie` does not read `authProxy.redisCredentialsSecret`
* `authProxy.passAccessToken` follows the session store unless set: `true` for `redis`, `false` for `cookie`
* `authProxy.cookieExpire` sets `--cookie-expire` and defaults to `168h` when unset

# 0.3.0
* Removed deprecated `PersistentRedisConnection` in favor of `PersistentRedisConnections`
* Documented hostname as either a static value or a Kubernetes secret (`hostnameSecret` / `hostnameSecretKey`)
* Added support for retrieving port and username from a Kubernetes secret (`portSecret` / `portSecretKey`, `usernameSecret` / `usernameSecretKey`)

# 0.2.2
* Added support hostname retrieval from the k8s secret via hostnameSecret and hostnameSecretKey

# 0.2.1
* Added support for TLS on each redis persistent connection

# 0.2.0
* Added support for multiple persistent Redis connections. Introduced `PersistentRedisConnections` with array-based configuration
* BACKWARD COMPATIBILITY: Maintained support for legacy `PersistentRedisConnection` format
* upgraded to redis-insight 2.70.1

# 0.1.1
* added persistent redis connection
* increment redis version from 2.66 to 2.70 (persistent redis connection string is supported >=2.68)

# 0.1.0

* made the first version of the helm, supporting oauth proxy and the latest image of redis insight