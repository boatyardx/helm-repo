# Shipyard SonarQube Helm Chart

SonarQube 8.7 Community Edition.

## Chart Details

This chart is a wrapper around the [community maintained SonarQube Helm Chart](https://github.com/Oteemo/charts/tree/master/charts/sonarqube).

The focus of this chart is to provide sensible defaults (e.g. force authentication, SSO with Keycloak)
and install plugins for code analysis on Shipyard back end and front end applications.

The following plugins are installed by default:

* Checkstyle
* PMD  
* Sonar Auth OpenID Connect (for Keycloak SSO)
* OWASP Dependency Check
* Groovy Language support  
* Container Vulnerability Plugin

## Installing the Chart

It's recommended to install this Chart using the [Terraform SonarQube Module](https://gitlab.tooling.shipyardtech.com/shipyard/terraform/terraform-sonarqube-module)
as it will create Kubernetes secrets and change the default SonarQube admin password automatically.
 
Please refer to the Terraform SonarQube Module for more information.
