# CHANGELOG

## 1.0.0

* changed repo of the chart, as the old one has been deprecated

## 0.4.0

* Update upstream Oteemo SonarQube Helm Chart to 9.5.0
* Use SonarQube 8.7.0-community.

## 0.3.2

* Update URL for container-check-plugin JAR

## 0.3.1

* Fix compatibility issue with Container Check and Dependency Check plugins (see https://github.com/ministryofjustice/container-check-sonar-plugin/issues/5)

## 0.3.0

* Add Sonar Groovy plugin
* Add (experimental) Container Vulnerability Plugin

## 0.2.0

* Add Dependency Check plugin
* Add Find Bugs plugin

## 0.1.0

Initial release.
