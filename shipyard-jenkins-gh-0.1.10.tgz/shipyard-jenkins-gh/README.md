# Shipyard Jenkins Helm Chart

Jenkins master and agent cluster utilizing the Jenkins Kubernetes plugin.

## Chart upgrade

To be able to increment the **Jenkins** version of the helm chart you need to
1. increment the helm chart in the `requirements.yaml`
2. update the app version and the chart version in the `chart.yaml`
3. run `helm dep update` in shipyard-jenkins-gh directory

## Chart Details

This chart is a wrapper around the [official Jenkins Helm Chart](https://github.com/jenkinsci/helm-charts).

The focus of this chart is to configure all aspects of Jenkins
using [JCasC](https://github.com/jenkinsci/configuration-as-code-plugin) (Jenkins Configuration as Code).
The parent chart is also adopting this approach.

The aspects/plugins below are currently managed with JCasC:

* Jenkins credentials (the actual secret values are stored in Kubernetes secrets)
* Git configuration (git username and git email for commit initiated by Jenkins)
* GitLab configuration
* Seed job DSL (scan GitLab groups and auto import projects)
* Global pipeline libraries
* Global script security
* Kubernetes cloud configuration
* Build agent pod templates
* Keycloak SSO
* Authorization strategy (matrix authorization)
* SonarQube.

## Installing the Chart

It's recommended to install this chart using the [Terraform Jenkins Module](https://gitlab.tooling.shipyardtech.com/shipyard/terraform/terraform-jenkins-module).

The Terraform module is responsible for:

* creating a dedicated user for Jenkins on GitLab
* generating a SSH key so that Jenkins can perform SCM operations
* generating a GitLab API Token to update GitLab about the status of the builds
* store secrets keys in Kubernetes secrets.
 
Please refer to the Terraform Jenkins Module for more information.

## Configuration

The paragraphs below describe only the Shipyard specific customizations applied by this chart.
Please refer to parent chart documentation for general information.

### Keycloak SSO

[Keycloak Plugin](https://github.com/jenkinsci/keycloak-plugin) configuration.

| Parameter | Description | Default | Required |
| :--- | :--- | :--- | :---: |
| `jenkins.controller.keycloak.realm` | Keycloak Realm | | yes |
| `jenkins.controller.keycloak.authServerUrl` | Keycloak Auth URL | | yes |
| `jenkins.controller.keycloak.resource` | Keycloak Client ID | | yes |
| `jenkins.controller.keycloak.administrators` | List of email addresses with admin access to Jenkins | `[]` | no |

*values.yaml*
```yaml
jenkins:
  controller:
    keycloak:
      realm: mycompany-realm
      authServerUrl: https://iam.tooling.mycompany.com/auth
      resource: jenkins-mycompany
      administrators:
        - admin1@domain.com
        - admin2@domain.com
```

### GitLab

[GitLab Plugin](https://github.com/jenkinsci/gitlab-plugin) configuration.

| Parameter | Description | Default | Required |
| :--- | :--- | :--- | :---: |
| `jenkins.controller.gitlab.name` | Name to identify your GitLab server | | yes |
| `jenkins.controller.gitlab.serverUrl` | GitLab server URL | | yes |
| `jenkins.controller.gitlab.projectOwner` | **DEPRECATED. Use `organizationFolders` instead.** Path to a GitLab group or subgroup. The seed job will scan and import projects in this group or subgroup.  | | no |
| `jenkins.controller.gitlab.organizationFolders` | Map of GitLab groups to scan. Each group is imported as a separate Organization Scan Folder and Seed Job. | | yes |
| `jenkins.controller.gitlab.credentialsId` | Credential id containing the SSH key used for SCM operations | `gitlab-ssh` | no |
| `jenkins.controller.gitlab.pipelineScriptPath` | Path to a Jenkinsfile. Only projects containing a file matching the path will be imported.  | `Jenkinsfile` | no |

*values.yaml*
```yaml
jenkins:
  controller:
    gitlab:
      name: mycompany-gitlab
      serverUrl: https://gitlab.tooling.mycompany.com
      organizationFolders:
        - id: "group-1" # unique identifier
          displayName: "Group One"
          projectOwner: "group1" # specify the namespace which owns your projects. It can be a user, group or subgroup (with full path).
        - id: "group-2"
          displayName: "Group Two"
          projectOwner: "group2/subgroup"
```

### Git

[Git Plugin](https://github.com/jenkinsci/git-plugin) configuration.

| Parameter | Description | Default | Required |
| :--- | :--- | :--- | :---: |
| `jenkins.controller.git.name` | Set `git config --global user.name` | `Jenkins` | no |
| `jenkins.controller.git.email` | Set `git config --global user.email` | `jenkins@noplace.com` | no |

*values.yaml*
```yaml
jenkins:
  controller:
    git:
      name: Jenkins CI
      email: jenkins-ci@mycompany.com
```

### Maven repositories

Define private Maven repositories where to fetch dependencies and upload new artifacts.
These must match the repository ids defined in the `distributionManagement` and
`repositories` blocks of your pom files.

If there's at least one element in the `jenkins.controller.maven.repositories` list,
the chart creates a Jenkins credential with id `maven-credentials` of type secret file.
The actual file content is read from the mounted Kubernetes secret file, key `MAVEN_CREDENTIALS`.
If you use the Terraform Jenkins module this is done automatically.

| Parameter | Description | Default | Required |
| :--- | :--- | :--- | :---: |
| `jenkins.controller.maven.repositories` | List of Maven repo ids | [] | no |

*values.yaml*
```yaml
jenkins:
  controller:
    maven:
      repositories:
        - my-snapshot-repo
        - my-release-repo
```

*pom.xml*
```xml
<distributionManagement>
  <snapshotRepository>
    <id>my-snapshot-repo</id>
    <url>bs://mycompanymavenrepo.blob.core.windows.net/snapshot</url>
  </snapshotRepository>
  <repository>
    <id>my-release-repo</id>
    <url>bs://mycompanymavenrepo.blob.core.windows.net/release</url>
  </repository>
</distributionManagement>
```

*Jenkinsfile*
```groovy
steps {
  container('mvn') {
    withCredentials([file(credentialsId: 'maven-credentials', variable: 'MVN_SETTINGS')]) {
      sh 'mvn --settings $MVN_SETTINGS clean compile'
    }
  }
}  
```

### Docker registries

Define private Docker registries where to fetch and upload Docker images.

**Note**: if your Kubernetes cluster and your Docker registry are hosted by the same cloud provider
then you can authenticate with the registry using your cloud provider specific methods (e.g. `gcloud auth`, `az login`, etc)
and you don't need to configure Jenkins with the Docker registry admin credentials.

The chart adds a credential of type username/password for each element in `jenkins.controller.docker.registries`.
The actual username/password values are read from the mounted Kubernetes secret file.
E.g. if the registry is `mycompanyregistry.azurecr.io`, the chart creates a
credential with id `mycompanyregistry-azurecr-io` and reads username and password
from secret keys `MYCOMPANYREGISTRY_ACURECR_IO_USERNAME` and `MYCOMPANYREGISTRY_ACURECR_IO_PASSWORD`. 
If you use the Terraform Jenkins module this is done automatically.

*values.yaml*
```yaml
jenkins:
  controller:
    docker:
      registries:  
        - mycompanyregistry.azurecr.io
```

*Jenkinsfile*
```groovy
steps {
  container('docker') {
    withCredentials([usernamePassword(credentialsId: 'mycompanyregistry-azurecr-io', usernameVariable: 'DOCKER_USERNAME', passwordVariable: 'DOCKER_PASSWORD')]) {
      sh 'docker login -u $DOCKER_USERNAME -p $DOCKER_PASSWORD mycompanyregistry.azurecr.io'
      sh 'docker build ...'
      sh 'docker push ...' 
    }
  }
}
```

### Kubernetes deployment environments

Define the environments where the pipelines will be able to deploy to.

The chart adds a credential with id `k8s-${clusterName}-config` of type secret file 
for each element in `jenkins.controller.kubernetes.deploymentClusters`.
The actual KubeConfig content is read from the mounted Kubernetes secret file,
key `K8S_${clusterName}_CONFIG` (all uppercase).
If you use the Terraform Jenkins module this is done automatically.

| Parameter | Description | Default | Required |
| :--- | :--- | :--- | :---: |
| `jenkins.controller.kubernetes.deploymentClusters` | List of Kubernetes cluster names | [] | no |

*values.yaml*
```yaml
jenkins:
  controller:
    kubernetes:
      deploymentClusters:
        - test
        - uat
        - prod
```

*Jenkinsfile*
```groovy
steps {
  container('helm') {
    withCredentials([file(credentialsId: "k8s-test-config", variable: 'KUBECONFIG')]) {
      dir("charts/my-service") {      
        sh 'helm upgrade my-service . --install -f values.yaml -f test.values.yaml --wait'
      }
    }
  }
}
```

### Jenkins agents configuration

[Kubernetes Plugin](https://github.com/jenkinsci/kubernetes-plugin) configuration.

The chart configures the Kubernetes plugin with a base agent pod template named `jenkins-pipeline`.

| Parameter | Description | Default | Required |
| :--- | :--- | :--- | :---: |
| `jenkins.controller.kubernetes.idleMinutes` | Amount of time in minutes after which an agent is deallocated. | `1440` (24 hours) | no |
| `jenkins.controller.kubernetes.maxAgentsNumber` | The maximum number of concurrently running agent pods that are permitted in this Kubernetes Cloud. Set to 0 means no pod will ever be started. | `10` | no |
| `jenkins.controller.kubernetes.agentPodTemplate.labels` | Map of additional labels to add to the Kubernetes pod | {} | no |
| `jenkins.controller.kubernetes.agentPodTemplate.containers` | List of containers to add to the agent pod | see *values.yaml* | no |
| `jenkins.controller.kubernetes.agentPodTemplate.annotations` | Map of additional annotations to add to the Kubernetes pod | {} | no |

```yaml
jenkins:
  controller:
    kubernetes:
      idleMinutes: 2880 # 2 days
      agentPodTemplate:
        labels:
          mycustomlabel: mycustomlabelvalue
        annotations:
          mycustomannotation: mycustomannotationvalue
        containers:
          - name: mvn
            image: my-custom-maven-image:1.2.3
            command:
              - cat
            tty: true
``` 

**Note:** the JNLP container is addedd automatically by the Jenkins Kuberntes plugin,
unless you define a container with name `jnlp`.

**Note:** you need to define the agent to use in your pipeline.

*Jenkinsfile*
```groovy
pipeline {
  agent {
    kubernetes {
      inheritFrom 'jenkins-pipeline'
      label 'jenkins-pipeline'
    }
  }  
}
```

I's possible to override the configuration of the base pod template 
(e.g. change the image of only one container) or define a completely custom agent.
Please refer to the plugin documentation for more details and examples.

By default, the Jenkins Agent pods are configured to try to schedule them evenly across all available nodes.
You can add the label `shipyardtech.com/factoryService` and value `CICD` will be preferred if available.

### Global Shared Libraries

[Global Shared Libraries](https://jenkins.io/doc/book/pipeline/shared-libraries/#global-shared-libraries) configuration.
These libraries are considered "trusted" and they can run any methods in Java, Groovy, Jenkins internal APIs, Jenkins plugins, or third-party libraries.

| Parameter | Description | Default | Required |
| :--- | :--- | :--- | :---: |
| `jenkins.controller.globalLibraries` | List of global libraries | [] | no |
| `jenkins.controller.globalLibraries[*].name` | Library name | | yes |
| `jenkins.controller.globalLibraries[*].gitUrl` | Git URL (git or https) | | yes |
| `jenkins.controller.globalLibraries[*].defaultVersion` | Default library version. It can be a branch name, a tag, or a git hash. | `controller` | no |
| `jenkins.controller.globalLibraries[*].allowVersionOverride` | Allow users to use a different version of the library | `false` | no |
| `jenkins.controller.globalLibraries[*].credentialsId` | The credential id with the credentials to access the repository  | | no |

*values.yaml*
```yaml
jenkins:
  controller:
    globalLibraries:
      - name: shipyard-pipeline-lib
        gitUrl: https://github.com/sy-tech/jenkins-pipeline.git
        defaultVersion: generic-provider
        allowVersionOverride: true
```

### Script approval

[Script approval](https://jenkins.io/doc/book/managing/script-approval/) configurations.
Pipelines will be able to use the approved methods.

| Parameter | Description | Default | Required |
| :--- | :--- | :--- | :---: |
| `jenkins.controller.scriptApproval` | List of approved method signatures | [] | no |

*values.yaml*
```yaml
jenkins:
  controller:
    scriptApproval:
      - "method groovy.json.JsonSlurperClassic parseText java.lang.String"
      - "method java.util.Collection toArray"
```

### SonarQube

[SonarQube Scanner](https://plugins.jenkins.io/sonar/) configuration.

| Parameter | Description | Default | Required |
| :--- | :--- | :--- | :---: |
| `jenkins.controller.sonarqube_installations` | List of SonarQube installations. | [] | no |
| `jenkins.controller.sonarqube_installations.name` | Identifier for the SonarQube installation. | | yes |
| `jenkins.controller.sonarqube_installations.serverUrl` | URL of the SonarQube installation. The access token for the server is read from the Kubernetes secret `jenkins-secrets`, key `${INSTALLATION_NAME}_TOKEN`. | | yes |
| `jenkins.controller.sonarqube_installations.securedWebhook` | If true, the SonarQube Jenkins plugin validates callbacks coming from the SonarQube server. See [https://docs.sonarqube.org/latest/project-administration/webhooks/#header-3](https://docs.sonarqube.org/latest/project-administration/webhooks/#header-3). The secret string used to create the HMAC hex digest is read from the Kubernetes secret `jenkins-secrets`, key `${INSTALLATION_NAME}_WEBHOOK_SECRET`. | | yes |
| `jenkins.controller.sonarqube_installations.sonarMavenPluginVersion` | Sonar Maven plugin version. | `5.3.2` | no |
| `jenkins.controller.sonarqube_installations.additionalArguments` | Additional command line arguments to be passed to the SonarQube scanner, e.g. `-X`. | `` | no |    
| `jenkins.controller.sonarqube_installations.additionalAnalysisProperties` | Additional analysis properties in the form of key-value pairs, e.g. `sonar.analysis.mode=issues`. | `` | no |
| `jenkins.controller.sonarqube_installations.skipIfTriggeredBySCMChanges` | Skip SonarQube if triggered by SCM Changes. It applies only to jobs with SonarQube as a post build action. | `false` | no |
| `jenkins.controller.sonarqube_installations.skipIfTriggeredByDependencyBuild` | Skip SonarQube if triggered by the build of a dependency. It applies only to jobs with SonarQube as a post build action. | `false` | no |

*values.yaml*
```yaml
jenkins:
  controller:
    sonarqube_installations:
      - name: sonarqube
        serverUrl: https://sonar.tooling.my-company.com
        securedWebhook: true
```

### Credentials

This chart supports adding in custom credentials.

| Parameter | Description | Default | Required |
| :--- | :--- | :--- | :---: |
| `jenkins.controller.credentials` | List of credentials. | [] | no |
| `jenkins.controller.credentials.userpasswords` | List of username and passwords ids stored in kubernetes secrets | [] | no |
| `jenkins.controller.credentials.files` | List of secret files ids stored in kubernetes secrets | [] | no |
| `jenkins.controller.credentials.secrettexts` | List of secret texts and ids stored in kubernetes secrets | [] | no |

## Get the list of installed plugins

Some Jenkins plugins are pseudo-plugins to install several plugins (e.g. `workflow-job`) or have dependencies on other plugins.
It's recommended to lock all plugin versions to avoid Jenkins to install/update plugins in a way that breaks other plugins.

The code below can be used in `https://<your jenkins instance>/script` to get the list of plugins.

```groovy
def pluginList = new ArrayList(Jenkins.instance.pluginManager.plugins)
pluginList.sort { it.getShortName() }.each{
  plugin -> 
    println ("- \"${plugin.getShortName()}:${plugin.getVersion()}\"")
}
```
