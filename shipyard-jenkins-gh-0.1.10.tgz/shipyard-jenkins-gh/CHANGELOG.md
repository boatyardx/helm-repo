# Change Log

The release numbering uses [semantic versioning](http://semver.org).

## 0.1.10
* set the dind image to be dynamically passed through as an argument in the chart values

## 0.1.9
* updated Jenkins version to v 2.479.3 (helm 5.8.7)

## 0.1.8
* added parameters for agents timeouts

## 0.1.7
* added customisable resources for the agents containers

## 0.1.6
* updated to jenkins 2.440.3

## 0.1.5
* Updated to Jenkins 2.440.2
* Fixed an issue regarding user rights since a breaking change in matrix-auth appeared in version 3.2

## 0.1.4
* Updated to Jenkins 2.440.1
* Updated the networking API to support k8s 1.27.7

## 0.1.3
* Updated the dind (docker in docker) image from 20.10.13 to 24.0.6

## 0.1.2
* Pinned snakeyaml-api version to 1.33-95.va_b_a_e3e47b_fa_4 as agents weren't starting properly

## 0.1.1
* Fixed a bug for Jenkins secret texts credentials
* Pinned Keycloak version to 2.3.0 as later builds are breaking atm

## 0.1.0
* Removed all version pins from plugins
* !!!This will mean that plugins are always updated on pod reschedule!!!

## 0.0.6
* Fixing topics bug

## 0.0.5
* Adding in the ability to filter by Github topics for the Seed Job.
* Resolved a plugin dependency