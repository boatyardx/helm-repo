This helm chart is a modified version of [heywook8 redis-insight helm chart](https://github.com/heywood8/helm-charts/blob/main/charts/redisinsight/README.md)

This template is capable of deploying a kube ingress and add an auth panel through keycloak oidc.

Flux deployment example
```yaml
apiVersion: helm.toolkit.fluxcd.io/v2
kind: HelmRelease
metadata:
  name: redis-insight
  namespace: redis
spec:
  releaseName: redis-insight
  interval: 5m
  timeout: 10m
  install:
    remediation:
      retries: 3
  upgrade:
    remediation:
      #      retries: 3
      remediateLastFailure: true
  chart:
    spec:
      chart: redis-insight
      version: "=0.1.0"
      sourceRef:
        kind: HelmRepository
        name: byx-chart-repo
        namespace: flux-system

  ## Default chart values here -> https://github.com/boatyardx/engine-helm-charts/blob/master/stable/redis-insight/values.yaml
  values:
    nameOverride: "cached-hotels"

    # image:
    #   repository: redis/redisinsight
    #   tag: "2.66"
    #   pullPolicy: IfNotPresent      

    ingress:
      enabled: true
      annotations:
        cert-manager.io/cluster-issuer: letsencrypt-production
        kubernetes.io/ingress.class: nginx
        appgw.ingress.kubernetes.io/request-timeout: "60" #as per doc recomendations
      hosts:
        - r3disinsight.ui.test.lifestylesolutionsteam.com
      tls:
        - hosts:
            - r3disinsight.ui.test.lifestylesolutionsteam.com
          secretName: redisinsight-test-lifestylesolutionsteam-com
      # pathType: "ImplementationSpecific"
      # path: "/"

    service:
      type: ClusterIP
      port: 5555

    resources:
      limits:
        memory: 1Gi
      requests:
        cpu: 1m
        memory: 150Mi

    # For redisinsight versions < 2 set the same as ingress
    trustedOrigins: ''

    serviceAccount:
      # Specifies whether a service account should be created
      create: false

    ## the persistent volume doesn't save the connection config
    persistentVolumeClaim:
      create: false
      accessMode: ReadWriteOnce
      storageClassName: ''
      # Small storage should do
      storage: 128Mi
    
    nodeSelector:
        redis_cluster: "true"
    tolerations:
      - key: "redis_cluster"
        operator: "Equal"
        value: "true"
        effect: "NoSchedule"


    authProxy:
      enabled: true
      containerPort: 5010
      ## Must be provided when enabling authProxy
      oidcIssuerUrl: "https://iam.tooling.projectdomain.com/auth/realms/your-realm"
      oidcClientId: "oauth2-proxy"
      oidcClientSecrets: "redis-insight-secrets" #k8s secret with keys: OAUTH_UPTIME_CLIENT_SECRET, OAUTH_UPTIME_COOKIE_SECRET
      redisCredentialsSecret: "redis-insight-secrets" #k8s secret wit keys host,port,primaryAccessKey
```

## Persistent Redis Connections

This chart supports configuring persistent Redis connections that will be automatically available in Redis Insight upon startup.

### Multiple Connections (New Format)

You can configure multiple Redis connections using the new `PersistentRedisConnections` format:

```yaml
PersistentRedisConnections:
  enabled: true
  connections:
    - hostname: "redis-primary.example.com"
      alias: "Primary Redis"          # Optional: defaults to hostname
      port: "6379"                    # Optional: defaults to "6379"
      username: "default"             # Optional: defaults to "default"
      passwordSecret: "redis-primary-secret"
      passwordSecretKey: "password"   # Optional: defaults to "redis-password"
    - hostname: "redis-secondary.example.com"
      alias: "Secondary Redis"
      port: "6380"
      username: "admin"
      passwordSecret: "redis-secondary-secret"
      passwordSecretKey: "redis-password"
    - hostname: "redis-cache.example.com"
      passwordSecret: "redis-cache-secret"
      # Only hostname and passwordSecret are required
      # Other values will use defaults
```

### Single Connection (Legacy Format - Deprecated)

For backward compatibility, the old single connection format is still supported but deprecated:

```yaml
PersistentRedisConnection:
  enabled: true
  hostname: "redis.example.com"
  alias: "My Redis"
  port: "6379"
  username: "default"
  passwordSecret: "redis-secret"
  passwordSecretKey: "redis-password"
```

**Note**: You should use either `PersistentRedisConnections` OR `PersistentRedisConnection`, not both.

### Required Kubernetes Secrets

Each connection requires a Kubernetes secret containing the Redis password:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: redis-primary-secret
type: Opaque
data:
  password: <base64-encoded-password>  # or redis-password if using default key
```