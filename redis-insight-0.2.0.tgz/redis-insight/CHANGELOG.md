# CHANGELOG

# 0.2.0
* Added support for multiple persistent Redis connections. Introduced `PersistentRedisConnections` with array-based configuration
* BACKWARD COMPATIBILITY: Maintained support for legacy `PersistentRedisConnection` format
* upgraded to redis-insight 2.70.1

# 0.1.1
* added persistent redis connection
* increment redis version from 2.66 to 2.70 (persistent redis connection string is supported >=2.68)

# 0.1.0

* made the first version of the helm, supporting oauth proxy and the latest image of redis insight