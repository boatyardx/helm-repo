# Spring Boot Helm Chart

## 1.1.1
* Use HPA "apiVersion: autoscaling/v2beta2" if supported, else "apiVersion: autoscaling/v2"