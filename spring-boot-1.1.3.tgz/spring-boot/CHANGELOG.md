# CHANGELOG

## 1.1.3

* Added azureWorkloadIdentity capability for the service account (disabled by default)
* Added lifecycle hooks (preStart / preStop) (disabled by default)
* Added helm hooks (pre/post install, upgrade, rollback, delete) (disabled by default)
* Added pods scheduling on nodes with specific labels using nodeSelector (disabled by default)
* Added tolerations to allow pods to run on tainted nodes (disabled by default)
* Added startupProbe - can be enabled for faster startup detection (disabled by default)
* Made minReadySeconds configurable (default: 60), terminationGracePeriodSeconds configurable for pod shutdown grace time (default: 30)
* Changed the deployment strategy to fix a conflict if the "recreate" strategy is used
* Changed the pod spread topology to filter after the release name value

## 1.1.2

* Added topologySpreadConstraints so that you can request the replicas to be deployed evenly accross all nodes

## 1.1.1

* HPA version updated to support newer k8s versions

## 1.1.0 APM integration

* Add configurations for enabling Elastic APM or Datadog APM.
  * https://docs.datadoghq.com/tracing/trace_collection/library_injection_local/?tab=kubernetes
  * https://www.elastic.co/guide/en/apm/attacher/current/apm-webhook-add-pod-annotation.html

## 1.0.4 Configurable HW requests/limits

* HW resources (limits and requests) can now be addresed and customized. The old hardcoded values are now set as defaults in case nothing is specified.

## 1.0.3 Fix spring-boot annotations

* Incorrect indentation in spring-boot/deployment.yaml caused annotations to break deployment

## 1.0.2 Kubernetes 1.23

* ingress apiVersion extensions/v1beta1 was changed to extensions/v1

## 1.0.1 RollingUpdate with HAP

* When applying HPA the "replicas" tag needs to be dropped from deployment descriptor. See https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/
* Deployment strategy is customizable

## 1.0.0 Kubernetes 1.22.

* Ingress apiVersion networking.k8s.io/v1
* Ingress spec.path.serviceName -> spec.path.service.name
* Ingress spec.path.servicePort -> spec.path.service.port.number

## 0.11.4

* ingress apiVersion extensions/v1beta1 not supported anymore

## 0.11.3

* Ingress annotation must specify "ingress.class: nginx" for external-dns

## 0.11.2

* Fixed issue with AKS 1.20 not being able to recognize the behavior config options in the autoscaler configuration.

## 0.11.1

* Fix indentation in the hpa file

## 0.11.0

* Add Auto Scaling 
* !!!! This release is broken due to indentation issues in hpa configs. Please do not use this version.

## 0.10.0

* Lock busybox container tag to 1.32.1 to avoid pulling the image every time a pod is created and hit DockerHub rate limits
* Add variable to remove the HTTP Wire Logs container.

## 0.9.3

* Add ability to configure pod CPU and memory resources 

## 0.9.2

* Increase `initialDelaySeconds` to `120` and `failureThreshold` to `6` for liveness and readiness probes. 
