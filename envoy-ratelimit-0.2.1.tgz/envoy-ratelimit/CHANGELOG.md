# Change Log

The release numbering uses [semantic versioning](http://semver.org).

## 0.2.1

* Fix ServiceMonitor spec bug (invalid type for `spec.endpoints.interval`).

## 0.2.0

* Add Prometheus Operator Service Monitor.

## 0.1.0

Initial release
