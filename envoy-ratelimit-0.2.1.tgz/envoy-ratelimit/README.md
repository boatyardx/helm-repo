# envoy-ratelimit

Go/gRPC service designed to enable generic rate limit scenarios from different types of applications.

## TL;DR;

```shell
$ helm repo add shipyard https://shipyard-helm-charts.s3.amazonaws.com
$ helm install envoy-ratelimit shipyard/envoy-ratelimit --set redis.url='my-redis-service:6379'
```

## Introduction

This chart bootstraps an [Envoy RateLimit](https://github.com/envoyproxy/ratelimit) deployment on
a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.11+
- Redis

## Add this Helm repository to your Helm client

```console
helm repo add shipyard https://shipyard-helm-charts.s3.amazonaws.com
```

## Installing the Chart

To install the chart with the release name `envoy-ratelimit`:

**If you are using an API Gateway like [Ambassador](https://www.getambassador.io) or [Gloo](https://www.solo.io/products/gloo-edge/)
it is recommended to install Envoy RateLimit in the same namespace in case you need
to control traffic using network policies or leverage a shared Redis installation.**

```console
$ kubectl create namespace api-gateway
$ helm install envoy-ratelimit shipyard/envoy-ratelimit -n api-gateway --set redis.url='my-redis-service:6379'
```

The command deploys Envoy RateLimit in the `api-gateway` namespace on the Kubernetes cluster in the default configuration.

The [configuration](#configuration) section lists the parameters that can be configured during installation.

## Uninstalling the Chart

To uninstall/delete the `envoy-ratelimit` deployment:

```console
$ helm uninstall envoy-ratelimit -n api-gateway
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Changelog

Notable chart changes are listed in the [CHANGELOG](./CHANGELOG.md)

## Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` |  |
| autoscaling.enabled | bool | `false` |  |
| autoscaling.maxReplicas | int | `100` |  |
| autoscaling.minReplicas | int | `1` |  |
| autoscaling.targetCPUUtilizationPercentage | int | `80` |  |
| config | string | `"domain: envoy\ndescriptors:\n  - key: generic_key\n    value: global\n"` | Envoy RateLimit configuration. See official documentation https://github.com/envoyproxy/ratelimit#configuration and examples https://github.com/envoyproxy/ratelimit/tree/main/examples/ratelimit/config for more information. |
| debugPort | int | `6070` |  |
| fullnameOverride | string | `""` |  |
| grpcPort | int | `8081` |  |
| httpPort | int | `8080` |  |
| image.pullPolicy | string | `"IfNotPresent"` |  |
| image.repository | string | `"envoyproxy/ratelimit"` |  |
| image.tag | string | `""` | Overrides the image tag whose default is the chart appVersion. |
| imagePullSecrets | list | `[]` |  |
| logFormat | string | `"json"` | The Ratelimit service can produce logs in text and json format |
| logLevel | string | `"info"` | Log level: debug, info |
| metrics.enabled | bool | `false` | Enable Prometheus /metrics endpoint via prom-statsd-exporter |
| metrics.serviceMonitor.enabled | bool | `false` | Create a Prometheus Operator ServiceMonitor resource |
| metrics.serviceMonitor.namespace | string | `""` | Namespace where to create the ServiceMonitor |
| metrics.serviceMonitor.path | string | `"/metrics"` |  |
| metrics.serviceMonitor.port | string | `"http-prometheus-metrics"` |  |
| metrics.serviceMonitor.scheme | string | `"http"` |  |
| metrics.serviceMonitor.scrapeInterval | string | `"30"` | Prometheus scrape interval in seconds |
| nameOverride | string | `""` |  |
| nodeSelector | object | `{}` |  |
| podAnnotations | object | `{}` |  |
| podSecurityContext | object | `{}` |  |
| redis.cacheKeyPrefix | string | `""` | A string to prepend to all cache keys (`CACHE_KEY_PREFIX`) |
| redis.password | string | `""` | Set to enable authentication to the Redis host (`REDIS_AUTH`) |
| redis.poolSize | string | `"5"` | Redis connection pool size (`REDIS_POOL_SIZE`) |
| redis.socketType | string | `"tcp"` | Redis socket type (`REDIS_SOCKET_TYPE`) |
| redis.tls | string | `"false"` | Set to "true" to enable a TLS connection (`REDIS_TLS`) |
| redis.url | string | `""` | A single hostname:port pair (`REDIS_URL`) |
| replicaCount | int | `1` |  |
| resources | object | `{}` |  |
| securityContext | object | `{}` |  |
| serviceAccount.annotations | object | `{}` | Annotations to add to the service account |
| serviceAccount.create | bool | `true` | Specifies whether a service account should be created |
| serviceAccount.name | string | `""` | The name of the service account to use. If not set and create is true, a name is generated using the fullname template |
| tolerations | list | `[]` |  |

### Redis

Envoy RateLimit uses Redis as its caching layer.

**This chart supports only the operation mode where one Redis server is used for all limits.**

**This chart does not provide a standalone deployment of Redis, so it must be available in your cluster.**

### Prometheus Metrics

You can use `metrics.enabled` and `metrics.serviceMonitor.enabled` to create a `ServiceMonitor` from the chart
if the [Prometheus Operator](https://github.com/coreos/prometheus-operator) has been installed on your cluster.

Please see [Envoy RateLimit Statistics](https://github.com/envoyproxy/ratelimit#statistics) docs for more information
on using the `/metrics` endpoint for metrics collection.
